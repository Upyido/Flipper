# FlipperZeroSub-GHz
Sub-GHz Files for the Flipper Zero

What deBruijn file do I use for what? 

![image](https://user-images.githubusercontent.com/101580720/160041184-d93d5231-31be-49b4-9ca9-0d4f1b1924b5.png)

Add to your X:\subghz folder on your SD card! 

UNLOCKED FIRMWARE REQUIRED!

Available here: https://github.com/MuddledBox/flipperzero-firmware/releases
