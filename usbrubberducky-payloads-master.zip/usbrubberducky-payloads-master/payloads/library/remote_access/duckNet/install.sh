mkdir ~/.config/duckNet
mv payload ~/.config/duckNet/
touch ~/.config/duckNet/duckNet.db 
chmod +x duckNetManager
sudo mv duckNetManager /bin/
mv Encoder ~/.config/duckNet/
