# FlipperAmiibo
Made to be used with Flipper just unzip & drag the folder (Amiibo Database 2018 - 2022) into NFC folder

Best way to select through Amiibo's is using Flipper Browser (Down arrow press then goto NFC clicking right arrow)  

https://www.youtube.com/watch?v=zRv7FZUCQng

Developer's build should fix any issues with certain Amiibo's that were not working properly because of read & write amiibos needed to function on flipper 
https://github.com/flipperdevices/flipperzero-firmware/pull/1179
