# Universal intercom keys

Универсальные ключи от домофонов

<pre>
Array
(
    [spb] => <a href="./spb">./spb</a>,
    [msk] => <a href="./msk">./msk</a>
)
</pre>

---

__from wetox with love__
